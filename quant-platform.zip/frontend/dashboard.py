import streamlit as st
import requests
import pandas as pd
import random

API_URL = "http://127.0.0.1:8000"

st.set_page_config(layout="wide")
st.title("AI Quant Trading Platform")

try:
    ai_data = requests.get(f"{API_URL}/ai-analysis").json()
    decision = requests.get(f"{API_URL}/trade-decision").json()
except:
    st.error("Backend offline")
    st.stop()

st.subheader("Market Scanner")
st.write({
    "asset": "BTC/USDT",
    "price": random.randint(100000, 110000),
    "trend": "BULLISH"
})

st.subheader("AI Brain")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Regime", ai_data["regime"])
col2.metric("Trade Prob", ai_data["trade_probability"])
col3.metric("Risk %", ai_data["risk_pct"])
col4.metric("Alpha", ai_data["alpha_score"])

st.subheader("Signal Decision")
st.write(decision)

st.subheader("Open Positions")
positions = pd.DataFrame([{
    "Asset": "BTC",
    "Side": "LONG",
    "Entry": 106500,
    "PnL": round(random.uniform(-2, 3), 2)
}])
st.dataframe(positions)

st.subheader("Portfolio")
c1, c2, c3 = st.columns(3)
c1.metric("Capital", "$10,000")
c2.metric("PnL Today", f"{round(random.uniform(-2,4),2)}%")
c3.metric("Drawdown", f"{round(random.uniform(1,8),2)}%")

st.subheader("Risk Monitor")
st.write({
    "daily_loss_limit": "OK",
    "exposure_limit": "OK",
    "kill_switch": "OFF"
})
