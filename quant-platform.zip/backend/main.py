from fastapi import FastAPI
import random

app = FastAPI(title="Quant Platform API")

@app.get("/")
def home():
    return {"status": "running"}

@app.get("/ai-analysis")
def ai_analysis():
    return {
        "regime": random.choice(["TRENDING_BULL", "RANGE", "VOLATILE"]),
        "trade_probability": round(random.uniform(0.75, 0.95), 2),
        "risk_pct": round(random.uniform(0.01, 0.03), 3),
        "alpha_score": round(random.uniform(75, 99), 2)
    }

@app.get("/trade-decision")
def trade_decision():
    return {
        "approved": random.choice([True, False]),
        "symbol": "BTC/USDT"
    }
